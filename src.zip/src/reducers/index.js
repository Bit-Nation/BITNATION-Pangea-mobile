import { combineReducers } from 'redux';
import initialState from './initialState';

const rootReducer = {
  initialState,
};

export default combineReducers(rootReducer);
