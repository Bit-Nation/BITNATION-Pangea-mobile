const logo = require('../assets/images/logo.png');
const background = require('../assets/images/background.png');
const rightArrow = require('../assets/images/right_arrow.png');
const ethereumLogo = require('../assets/images/ethereum_logo.png');
const demo = require('../assets/images/demo.png');

const Images = {
  logo,
  background,
  rightArrow,
  ethereumLogo,
  demo
};

export default Images;
